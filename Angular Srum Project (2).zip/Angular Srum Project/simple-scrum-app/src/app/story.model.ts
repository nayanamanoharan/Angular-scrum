export interface Story {
    name: string;
    points: number;
  }